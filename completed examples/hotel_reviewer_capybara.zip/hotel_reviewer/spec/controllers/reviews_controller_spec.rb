require 'rails_helper'

RSpec.describe ReviewsController, type: :controller do

end
