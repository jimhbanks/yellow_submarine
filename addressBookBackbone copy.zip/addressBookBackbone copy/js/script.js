var contact1 = new addressBookApp.Contact({name: 'Mathilda Thompson', number: '07548362845'});
var contact2 = new addressBookApp.Contact({name: 'Alex Thompson', number: '07854037465'});
var contact3 = new addressBookApp.Contact({name: 'Jeffery Dhamer', number: '07548434565'});

var addressBook = new addressBookApp.AddressBook([contact1, contact2, contact3]);