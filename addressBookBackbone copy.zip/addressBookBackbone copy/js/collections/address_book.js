addressBookApp.AddressBook = Backbone.Collection.extend({
  model: addressBookApp.Contact
})